
SPEED PROOFS - DEMON-X Mod Package
==================================

Contents:
---------
- DEMON-X-final       : Patched binary (uses new gist)
- DEMON-X-original    : Original binary (backup)
- driver_ko_670/      : Kernel modules (6 versions)
- driver_ko_670.zip   : Original driver archive
- launcher.sh         : Test script

Setup Instructions:
-------------------
1. Push binary to device:
   adb push DEMON-X-final /data/local/tmp/DEMON-X

2. Make executable:
   adb shell chmod +x /data/local/tmp/DEMON-X

3. Clear cache (if needed):
   adb shell rm -f /data/local/tmp/.expiry_resp

4. Run:
   adb shell /data/local/tmp/DEMON-X

License Check:
--------------
Binary checks gist at:
https://gist.githubusercontent.com/karloays01-prog/dc667903c5fc4db6621f03c494a03816/raw/d54596d6805232f224224a72140577d2e1ec76ffb/Fuckk

Content must be: V2|YYYY-MM-DD
Current expiry: 2099-12-31 (valid for 70+ years)

To expire later, edit gist content to current/past date.

Kernel Modules:
---------------
6 variants for different Android kernels:
- 5.10.ko  (Linux 5.10)
- 5.15.ko  (Linux 5.15)
- 6.1.ko   (Linux 6.1)
- 6.6.ko   (Linux 6.6)
- 6.12.ko  (Linux 6.12)
- 6.18.ko  (Linux 6.18)

Load via: insmod or ksud (KernelSU)

Notes:
------
- Binary is ARM64/aarch64 ELF
- Requires root access on device
- Works on real Android phones (ARM)
- May need ARM translation on x86 emulators
